using UnityEngine;
using UnityEngine.SceneManagement;

public class EnemyController : MonoBehaviour
{  
   // This will hold the name of the scene to load
    public string sceneToLoad; // Drag the scene name in the inspector

    private void OnTriggerEnter(Collider other)
    {
        // unlock the currser
        Cursor.lockState = CursorLockMode.None;
        if (other.CompareTag("Player"))
        {
            // Enter the specified turn-based mode scene when the player touches the enemy
            SceneManager.LoadScene(sceneToLoad);
        }
    }
}
