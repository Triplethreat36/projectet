using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PlayerMovement : MonoBehaviour
{
    public float horizontalInput;
    public float verticalInput;
    public float turnSpeed = 10f;
    public float moveSpeed = 5f; // Adjustable speed variable

    void Update()
    {
        // Get input for movement
        horizontalInput = Input.GetAxis("Horizontal");
        verticalInput = Input.GetAxis("Vertical");

        // Move the player forward/backward with adjustable speed
        transform.Translate(Vector3.forward * Time.deltaTime * verticalInput * moveSpeed);

        // Move the player left/right with adjustable speed
        transform.Translate(Vector3.right * Time.deltaTime * horizontalInput * moveSpeed); // Removed the negative sign
    }
}
