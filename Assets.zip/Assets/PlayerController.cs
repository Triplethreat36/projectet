using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float mouseSensitivity = 100f;

    public Transform cameraTransform;

    private float cameraPitch = 0f;

    void Update()
    {
        // Rotate the camera with mouse movement
        RotateCamera();

        // Move player relative to camera direction
        MovePlayerRelativeToCamera();
    }

    void RotateCamera()
    {
        // Get mouse input for camera rotation
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        // Rotate player horizontally based on mouse X (yaw rotation)
        transform.Rotate(Vector3.up * mouseX);

        // Adjust camera pitch (vertical rotation) and clamp it to avoid flipping
        cameraPitch -= mouseY;
        cameraPitch = Mathf.Clamp(cameraPitch, -45f, 45f);  // Limits looking up and down

        // Apply pitch rotation to the camera
        cameraTransform.localRotation = Quaternion.Euler(cameraPitch, 0f, 0f);
    }

    void MovePlayerRelativeToCamera()
    {
        // Get input for movement
        float moveHorizontal = Input.GetAxis("Horizontal"); // A, D keys
        float moveVertical = Input.GetAxis("Vertical");     // W, S keys

        // Get the forward direction relative to the camera's current orientation
        Vector3 forward = cameraTransform.forward;
        Vector3 right = cameraTransform.right;

        // Ensure movement is only along the XZ plane
        forward.y = 0f;
        right.y = 0f;

        forward.Normalize();
        right.Normalize();

        // Calculate the movement direction based on camera's forward/right
        Vector3 movementDirection = (forward * moveVertical + right * moveHorizontal).normalized;

        // Move the player in the direction calculated
        transform.Translate(movementDirection * moveSpeed * Time.deltaTime, Space.World);
    }
}
