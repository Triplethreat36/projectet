using UnityEngine;

public class GravityObject : MonoBehaviour
{
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        if (rb == null)
        {
            // Add Rigidbody if not already present
            rb = gameObject.AddComponent<Rigidbody>();
        }

        // Ensure gravity is enabled
        rb.useGravity = true;
    }
}
