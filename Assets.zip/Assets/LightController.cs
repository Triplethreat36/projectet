using UnityEngine;

public class LightController : MonoBehaviour
{
    private Light myLight;
    public UnifiedController unifiedController; // Reference to the shared controller

    void Start()
    {
        myLight = GetComponent<Light>();
    }

    void Update()
    {
        if (unifiedController != null)
        {
            // Synchronize light intensity with the shared value from UnifiedController
            float lightIntensity = unifiedController.currentIntensity;

            // Adjust light intensity to get darker by checking the minIntensity
            myLight.intensity = Mathf.Max(lightIntensity, unifiedController.minIntensity);
        }
    }
}
