using UnityEngine;

public class UnifiedController : MonoBehaviour
{
    public float maxIntensity = 5f; // Maximum intensity
    public float minIntensity = 0f; // Minimum intensity (darkness level)
    public float speed = 1f; // Speed of intensity change
    public float pauseAtMinDuration = 2f; // Duration to pause at minimum intensity

    [HideInInspector] public float currentIntensity = 0f; // Shared intensity value
    private bool increasing = true; // Direction of intensity change
    private float pauseTimer = 0f; // Timer for pause at minimum intensity

    void Update()
    {
        // Adjust the current intensity
        if (increasing)
        {
            currentIntensity += speed * Time.deltaTime;
            if (currentIntensity >= maxIntensity)
            {
                currentIntensity = maxIntensity;
                increasing = false; // Reverse direction
            }
        }
        else
        {
            currentIntensity -= speed * Time.deltaTime;
            if (currentIntensity <= minIntensity)
            {
                currentIntensity = minIntensity;

                if (pauseTimer <= 0f)
                {
                    pauseTimer = pauseAtMinDuration; // Start pause at minimum intensity
                }
                else
                {
                    pauseTimer -= Time.deltaTime; // Count down the pause timer
                    if (pauseTimer <= 0f)
                    {
                        increasing = true; // Resume increasing intensity
                    }
                    return; // Keep intensity at minimum during pause
                }
            }
        }
    }
}
