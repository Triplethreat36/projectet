using UnityEngine;

public class EmissionChanger : MonoBehaviour
{
    public Renderer objectRenderer; // Reference to the object's renderer
    public UnifiedController unifiedController; // Reference to the shared controller

    private Material material; // Material instance
    private Color originalEmissionColor; // Original emission color

    void Start()
    {
        if (objectRenderer == null)
        {
            objectRenderer = GetComponent<Renderer>();
        }

        if (objectRenderer != null)
        {
            // Get the material instance
            material = objectRenderer.material;

            // Enable emission in the shader
            material.EnableKeyword("_EMISSION");

            // Retrieve the original emission color
            if (material.HasProperty("_EmissionColor"))
            {
                originalEmissionColor = material.GetColor("_EmissionColor");
            }
            else
            {
                originalEmissionColor = Color.black; // Default to black if not set
            }
        }
    }

    void Update()
    {
        if (material == null || unifiedController == null)
            return;

        // Use the shared intensity value to set the emission intensity
        Color emissionColor = originalEmissionColor * unifiedController.currentIntensity;
        material.SetColor("_EmissionColor", emissionColor);
    }
}
